@extends('welcome')
@section('contenido')

<br><br><br>
<img src="{{ asset('images/maquetacion-acerca.png') }}" width="110%"  >
<img src="{{ asset('images/organigrama.svg') }}" width="110%"  >
<img src="{{ asset('images/creditos-2022.svg') }}" width="110%"  >

<a href="{{-- route('about') --}}">

{{-- <button type="button" class="btn btn-warning  btn-lg btn-block">&nbsp;&nbsp;&nbsp;&nbsp;Explorar&nbsp;&nbsp;&nbsp;&nbsp;</button> --}}</a>
@endsection