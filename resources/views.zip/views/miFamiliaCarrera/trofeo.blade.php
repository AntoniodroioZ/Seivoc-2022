 <!-- Modal -->
   <div class="modal fade" id="exampleModalLong1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
          <div class="modal-header">
            <center><h5 class="modal-title" id="exampleModalLongTitle1">EXCELENTE!</h5></center>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
           <h4>Ahora estamos más cerca de salvar a los estudiantes</h4>
          <div class="modal-body">
            <div class="content">
                    <img class="imgP" src="{{ asset('images/familiadecarreras/Area1_SN.png')}}">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="b1" data-dismiss="modal">Regresar</button>
          </div>
        </div>
      </div>
    </div>
    <!-- End Modal-->