@extends('welcome')
@section('contenido')
<br><br><br>

<img src="{{ asset('images/info-5.png') }}" width="110%"  >
<a href="{{ url('/MiFamiliadeCarrera') }}">
<button type="button" class="btn btn-warning  btn-lg btn-block MetaDataJCSeivoc" ReferenciaMetaSEIVOC="4001">&nbsp;&nbsp;&nbsp;&nbsp;Explorar&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
@endsection