@extends('welcome')
@section('contenido')
<br><br><br>
<img src="{{ asset('images/info-2.png') }}" width="110%"  >
<a class="MetaDataJCSeivoc" ReferenciaMetaSEIVOC="3" href="/guiaInteractiva">
<button type="button" class="btn btn-warning  btn-lg btn-block">&nbsp;&nbsp;&nbsp;&nbsp;Explorar&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
@endsection